# Build SARA APK using only your phone

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

1. Open your GitHub repository in Chrome and sign in.
2. Upload the **contents** of this folder to the repository root (keep the `.github/workflows/build-apk.yml` path).
3. Open the repository's **Actions** tab.
4. Select **Build SARA APK** and tap **Run workflow** (or wait for the push build).
5. Open the completed green workflow run.
6. Under **Artifacts**, download **SARA-debug-APK**.
7. Extract the artifact ZIP and tap `app-debug.apk` to install. If Android asks, allow Chrome/Files to install unknown apps.

Notes:
- This creates a debug APK, not a Play Store release.
- Android may show an installation warning because it is a personally built APK.
- This starter app does not yet implement all advanced SARA features (voice identity verification, robust low-power wake-word detection, cross-app typing/accessibility automation).
- Keep the `.github` folder and workflow path intact.
