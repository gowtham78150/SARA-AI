package com.sara.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 44
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 22)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 22)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(8, 11, 22))
        }
        fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        val title = text("SARA AI", 30f, 0xFF56E5FF.toInt())
        info = text("Your personal voice assistant\n\n1. Allow microphone permission.\n2. Start listening while this screen is open.\n3. Say: “Hey SARA” then a command.\n\nThis starter uses Android speech recognition. Always-on wake-word detection is not guaranteed on every phone.", 15f, 0xFFE8EEFF.toInt())
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(button("START SARA LISTENING") { requestAndStart() })
        layout.addView(button("STOP SARA") {
            stopService(Intent(this, ListeningService::class.java))
            stopService(Intent(this, FloatingBubbleService::class.java))
            info.text = "SARA stopped."
        })
        layout.addView(button("ENABLE FLOATING BUBBLE") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingBubbleService::class.java))
                Toast.makeText(this, "Floating SARA started", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(button("OPEN APP NOTIFICATION / PERMISSION SETTINGS") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        setContentView(layout)
    }

    private fun requestAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 23 && needed.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(needed.toTypedArray(), requestCode)
        } else startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == this.requestCode && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else info.text = "Microphone permission is required to use SARA."
    }

    private fun startListening() {
        if (Build.VERSION.SDK_INT >= 31) {
            // Start from visible Activity to satisfy Android microphone foreground-service rules.
            startForegroundService(Intent(this, ListeningService::class.java))
        } else startService(Intent(this, ListeningService::class.java))
        info.text = "SARA listening service started. Keep the notification visible. Say “Hey SARA” followed by a command."
    }
}
