package com.sara.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Toast
import java.util.Locale

class ListeningService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var restarting = false
    private var lastCommandAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        @Suppress("DEPRECATION")
        val legacyNotification = Notification.Builder(this)
            .setContentTitle("SARA is active").setContentText("Listening for commands")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("SARA is active")
            .setContentText("Microphone listening is on. Say “Hey SARA”.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).setOngoing(true).build()
        else legacyNotification
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIFICATION_ID, notification)
        tts = TextToSpeech(this, this)
        beginListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this phone.")
            return
        }
        try {
            recognizer?.destroy()
            recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else SpeechRecognizer.createSpeechRecognizer(this)

            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleRestart() }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    handleWords(words)
                    scheduleRestart()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) { scheduleRestart() }
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (recognizer != null) beginListening()
        }, 900)
    }

    private fun handleWords(raw: String) {
        val text = raw.lowercase(Locale.ROOT).trim()
        if (text.isBlank()) return
        if (text.contains("sara switch off") || text.contains("sarah switch off") || text == "switch off sara") {
            speak("SARA is switching off.")
            android.os.Handler(mainLooper).postDelayed({ stopSelf() }, 1200)
            return
        }
        val wake = listOf("hey sara", "hey sarah", "sara")
        val wakeIndex = wake.map { text.indexOf(it) }.filter { it >= 0 }.minOrNull()
        if (wakeIndex == null) return
        val command = text.substring(wakeIndex).replaceFirst(Regex("^(hey\\s+)?sara(h)?"), "").trim()
        if (command.isBlank()) { speak("Yes, Sir?"); return }
        runCommand(command)
    }

    private fun runCommand(command: String) {
        val now = System.currentTimeMillis()
        if (now - lastCommandAt < 1300) return
        lastCommandAt = now
        when {
            command.startsWith("open ") -> {
                val app = command.removePrefix("open ").trim()
                val pkg = when {
                    app.contains("youtube") -> "com.google.android.youtube"
                    app.contains("whatsapp") -> "com.whatsapp"
                    app.contains("instagram") -> "com.instagram.android"
                    app.contains("gmail") -> "com.google.android.gm"
                    app.contains("chrome") -> "com.android.chrome"
                    app.contains("maps") -> "com.google.android.apps.maps"
                    else -> null
                }
                val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); speak("Opening $app.") }
                else speak("I could not find that app.")
            }
            command.startsWith("search ") -> {
                val q = command.removePrefix("search ")
                val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(q)))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); speak("Searching for $q.")
            }
            command.contains("time") -> speak("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            command.contains("date") -> speak("Today is " + java.text.SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(java.util.Date()))
            command.startsWith("call ") -> {
                val name = command.removePrefix("call ").trim()
                val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("tel:"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                speak("Please use the phone app to choose and confirm the contact named $name.")
                startActivity(i)
            }
            command.startsWith("say ") -> speak(command.removePrefix("say "))
            else -> speak("I heard $command. This starter supports open app, search, time, date and say commands. Advanced AI needs a configured backend.")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale("en", "IN")
            val candidates = tts?.voices.orEmpty()
            val female = candidates.firstOrNull {
                it.locale.language == "en" && it.locale.country == "IN" &&
                (it.name.contains("female", true) || it.name.contains("woman", true))
            } ?: candidates.firstOrNull { it.locale == Locale("en", "IN") }
            if (female != null) tts?.voice = female
            tts?.setSpeechRate(0.94f)
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "sara-${System.currentTimeMillis()}")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "SARA voice assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "sara_voice_channel"
        const val NOTIFICATION_ID = 5101
    }
}
