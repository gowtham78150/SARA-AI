# SARA AI – Android starter project

This is a native Android Studio starter project (Kotlin, no third-party runtime libraries).

## Included now
- Android app shell and permission flow.
- Microphone foreground service with a persistent notification.
- Prefers Android on-device speech recognition when available; requests `en-IN` and offline recognition.
- Basic wake phrase gate: say “Hey SARA open YouTube”, “Hey SARA search cats”, “Hey SARA what is the time”, or “Hey SARA say hello”.
- Text-to-speech in Indian English locale; selects an English India voice if installed (female voice availability depends on the device's installed TTS voices).
- Movable-overlay permission flow and a floating S bubble that opens the app.
- “SARA switch off” stops the listening service.

## Important limitations (do not treat this as a finished production assistant)
1. Android `SpeechRecognizer` is not a guaranteed always-on, low-power hotword engine. This prototype repeatedly starts recognition sessions. Some speech providers require network access even when offline is requested; on-device recognition is used only when the device reports support. For reliable low-power “Hey SARA”, integrate a dedicated wake-word engine/model and a supported offline speech-to-text model.
2. Android 12+ restricts starting microphone foreground services from the background. Start listening from the visible app screen. Android 14+ requires microphone foreground-service permissions and a visible notification. Battery optimisation and OEM restrictions may still stop it.
3. The sample call command deliberately opens the phone UI and asks the user to confirm/select the contact. It does not place calls silently.
4. Voice matching / voice biometrics is not implemented. Do not use voice as the sole authentication factor; keep Android PIN/fingerprint.
5. Cross-app typing, screen reading, automatic UI taps, payment actions, and full app control are not included. Accessibility services are sensitive and must be user-enabled for a legitimate assistive purpose; payment and other sensitive actions should always require user confirmation.
6. This app cannot turn on a fully powered-off phone or bypass its lock screen.
7. No AI API key is included. Connect a secure backend for general ChatGPT-like answers; never embed a private API key in the APK.

## Build
- Open this folder in Android Studio.
- Use JDK 17 and Android SDK Platform 35.
- Allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- Install the debug APK on your phone.
- Open SARA, grant microphone permission, and tap START SARA LISTENING.
- To show the floating bubble, tap ENABLE FLOATING BUBBLE and grant “Display over other apps”.

## Test phrases
- “Hey SARA open YouTube”
- “Hey SARA open WhatsApp”
- “Hey SARA search Chennai weather”
- “Hey SARA what is the time”
- “Hey SARA what is the date”
- “Hey SARA say Hello Sir”
- “SARA switch off”

## Official Android references
- Foreground service types: https://developer.android.com/develop/background-work/services/fgs/service-types
- Microphone foreground-service restrictions: https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
- On-device SpeechRecognizer: https://developer.android.com/reference/android/speech/SpeechRecognizer#createOnDeviceSpeechRecognizer(android.content.Context)
- Accessibility service: https://developer.android.com/guide/topics/ui/accessibility/service
